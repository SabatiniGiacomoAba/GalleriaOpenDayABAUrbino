<?php
require("sessione.php");
//
function addNodeGraphicsXml($xml,$user,$tipo,$color,$cx1,$cy1,$cx2,$cy2){
	$nodo = $xml->addChild('forma_geometrica',"forma grafica di $user");
	$nodo->addAttribute('tipo',$tipo);
	$nodo->addAttribute('utente',$user);
	$nodo->addAttribute('colore',$color);
	$nodo->addAttribute('x1',$cx1);
	$nodo->addAttribute('y1',$cy1);
	$nodo->addAttribute('x2',$cx2);
	$nodo->addAttribute('y2',$cy2);
	return($xml);
}
session_start();
//
$xml = simplexml_load_file("forma.xml");
$tipo = $_POST["tipo"];
$colore = $_POST["colore"];
$cx1 = $_POST["cx1"];
$cy1 = $_POST["cy1"];
$cx2 = $_POST["cx2"];
$cy2 = $_POST["cy2"];
//
if(!isLogged())   {//se non è loggato torna al form e lo script termina
         header("Location: login.html");
         exit;  
 } else {
			$user = isLogged();
			echo (" Bene $user puoi concludere l'operazione<br>");
			echo (" forma geometrica scelta: $tipo <br>");
			echo (" nella posizione: $cx1 , $cy1 , $cx2, $cy2 <br>");
			if ( (strcmp($tipo, "punto") == 0) || (strcmp($tipo, "linea") == 0 ) || (strcmp($tipo, "rettangolo") == 0 ) || (strcmp($tipo, "ellisse") == 0 )){
				//echo ("punto<br>");
				addNodeGraphicsXml($xml,$user,$tipo,$colore,$cx1,$cy1,$cx2,$cy2);
			}else
				echo("Nessuna forma grafica selezionata<br>");
			$strfile="forme_geometriche/form_".time().".xml";
			echo("Memorizzazione nel file: $strfile <br>");
			$xml->asXML("$strfile");
			header("Location: visualizzazione_processing.html");
}
?>
