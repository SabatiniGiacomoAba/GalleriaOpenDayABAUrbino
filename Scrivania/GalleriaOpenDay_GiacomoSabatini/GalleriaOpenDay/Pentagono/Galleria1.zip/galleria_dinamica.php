<!DOCTYPE html>
<html>
<head>
<title>Galleria Processing</title>
<script src="js/processing.js"></script>
</head>
<body>
<b><div style="text-align: center"> <i>Galleria Processing</i></div></b><br>
<hr>
<table BORDER="0">
<?php
$dir    = 'pde/';
$weeds = array('.', '..'); 
$directories = array_diff(scandir($dir), $weeds);    
foreach($directories as $files) 
{ 
      //echo $value.'<br />'; 
      echo "<tr><td><canvas data-processing-sources=\"pde/$files\"></canvas></td></tr>";
} 
?>
</table>
<br><a href="index.html"> Home Page </a>
</body>
</html>
