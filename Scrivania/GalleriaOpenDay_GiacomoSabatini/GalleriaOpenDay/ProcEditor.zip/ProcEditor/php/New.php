<?php
require("../../sessione.php");
session_start();
 if(isLogged()) {
 $user = isLogged();
 
 $NewCommand = "rm /var/www/html/GalleriaOpenDay/ProcEditor/php/tempde/temp.$user.xml";
 $NewExe = shell_exec($NewCommand);
 echo $NewExe;
 header("Location: ProcEditor.php");
 }
?>