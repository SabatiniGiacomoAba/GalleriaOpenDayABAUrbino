XMLWriter
=========

XML generator for Javascript, based on .NET's XMLTextWriter.
